-- Eagle Studio : partage de programmes pour une équipe.
-- À coller dans Supabase > SQL Editor, puis « Run ».
-- Personne ne peut lire ou écrire les tables directement : tout passe par les 4 fonctions ci-dessous.

create extension if not exists pgcrypto;

create table if not exists public.teams (
  code        text primary key check (char_length(code) >= 8),
  name        text not null,
  publish_key text not null check (char_length(publish_key) >= 8),
  created_at  timestamptz not null default now()
);

create table if not exists public.programmes (
  id         uuid primary key default gen_random_uuid(),
  team_code  text not null references public.teams(code) on delete cascade,
  prog_name  text not null,
  prog_date  text not null default '',
  leader     text not null default '',
  payload    jsonb not null,
  updated_at timestamptz not null default now(),
  unique (team_code, prog_name, prog_date)
);

alter table public.teams enable row level security;
alter table public.programmes enable row level security;
-- Aucune politique volontairement : l'accès direct aux tables est fermé.
revoke all on public.teams from anon, authenticated;
revoke all on public.programmes from anon, authenticated;

-- Liste des programmes d'une équipe (il faut connaître le code)
create or replace function public.eagle_list(p_code text)
returns table (id uuid, prog_name text, prog_date text, leader text, updated_at timestamptz)
language sql security definer set search_path = public as $$
  select p.id, p.prog_name, p.prog_date, p.leader, p.updated_at
  from public.programmes p
  where p.team_code = p_code
  order by p.updated_at desc
  limit 50;
$$;

-- Contenu d'un programme
create or replace function public.eagle_get(p_code text, p_id uuid)
returns jsonb
language sql security definer set search_path = public as $$
  select p.payload from public.programmes p where p.team_code = p_code and p.id = p_id;
$$;

-- Publication (il faut le code ET la clé de publication)
create or replace function public.eagle_publish(
  p_code text, p_key text, p_name text, p_date text, p_leader text, p_payload jsonb
) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  if not exists (select 1 from public.teams t where t.code = p_code and t.publish_key = p_key) then
    raise exception 'Acces refuse';
  end if;
  if octet_length(p_payload::text) > 800000 then
    raise exception 'Programme trop volumineux';
  end if;
  insert into public.programmes (team_code, prog_name, prog_date, leader, payload, updated_at)
  values (p_code, left(p_name, 120), left(coalesce(p_date, ''), 60), left(coalesce(p_leader, ''), 60), p_payload, now())
  on conflict (team_code, prog_name, prog_date)
  do update set leader = excluded.leader, payload = excluded.payload, updated_at = now()
  returning id into v_id;
  return v_id;
end;
$$;

-- Suppression (code + clé de publication)
create or replace function public.eagle_delete(p_code text, p_key text, p_id uuid)
returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.teams t where t.code = p_code and t.publish_key = p_key) then
    raise exception 'Acces refuse';
  end if;
  delete from public.programmes where id = p_id and team_code = p_code;
end;
$$;

revoke all on function public.eagle_list(text) from public;
revoke all on function public.eagle_get(text, uuid) from public;
revoke all on function public.eagle_publish(text, text, text, text, text, jsonb) from public;
revoke all on function public.eagle_delete(text, text, uuid) from public;
grant execute on function public.eagle_list(text) to anon, authenticated;
grant execute on function public.eagle_get(text, uuid) to anon, authenticated;
grant execute on function public.eagle_publish(text, text, text, text, text, jsonb) to anon, authenticated;
grant execute on function public.eagle_delete(text, text, uuid) to anon, authenticated;

-- ÉTAPE SUIVANTE (à faire UNE fois, en changeant les deux valeurs) :
-- insert into public.teams (code, name, publish_key)
-- values ('CODE-EQUIPE-LONG-ET-UNIQUE', 'Eagle Message Tabernacle', 'CLE-DE-PUBLICATION-SECRETE');
