# AccordGo : mettre l'application en ligne

Ce dossier contient tout ce qu'il faut pour que l'équipe installe AccordGo sur son téléphone,
l'ouvre sans connexion, et reçoive les programmes du culte en ligne.

```
eagle-studio/
  netlify.toml          réglages pour Netlify
  supabase/schema.sql   base de données du partage d'équipe
  site/                 l'application (c'est ce dossier qui est mis en ligne)
    index.html          l'application
    config.js           adresse et clé Supabase (à remplir à l'étape 4)
    cloud.js            partage d'équipe en ligne
    manifest.webmanifest, sw.js, icons/   installation sur l'écran d'accueil et mode hors connexion
```

Tout est gratuit à cette échelle (Netlify et Supabase ont une offre gratuite).

## 1. Mettre le site en ligne avec Netlify

**Option A : depuis un ordinateur, la plus simple.**
1. Décompresse le dossier `eagle-studio`.
2. Va sur https://app.netlify.com/drop et glisse le dossier **`site`** (pas le dossier du dessus).
3. Netlify te donne une adresse en `https://…netlify.app`. Tu peux la renommer dans « Site configuration ».

**Option B : avec GitHub (permet les mises à jour automatiques).**
1. Crée un dépôt GitHub et envoie-y tout le contenu du dossier `eagle-studio`
   (sur github.com : « Add file » puis « Upload files »).
2. Sur Netlify : « Add new site » puis « Import an existing project » puis choisis le dépôt.
   Netlify lit `netlify.toml` tout seul. Laisse la commande de build vide.
3. À chaque fois que tu modifies un fichier dans GitHub, le site se met à jour.

L'adresse commence par `https://` : c'est obligatoire pour que le micro fonctionne.

## 2. Installer sur le téléphone

- **iPhone (Safari)** : ouvre l'adresse, touche « Partager » puis « Sur l'écran d'accueil ».
- **Android (Chrome)** : ouvre l'adresse, menu ⋮ puis « Installer l'application ».

Une icône d'aigle apparaît. L'application s'ouvre en plein écran et marche sans internet
(le partage d'équipe a besoin d'internet).

## 3. Tester avant d'inviter l'équipe

Ouvre l'application installée et vérifie : accordeur, métronome, une chanson, le rythme, un enregistrement.
Autorise le micro quand le téléphone le demande.

## 4. Activer le partage d'équipe (Supabase)

1. Crée un compte gratuit sur https://supabase.com, puis « New project » (choisis une région proche, note le mot de passe de la base).
2. Dans le projet : **SQL Editor** puis « New query ». Colle tout le contenu de `supabase/schema.sql` puis « Run ».
3. Toujours dans le SQL Editor, crée ton équipe (change les deux valeurs, 8 caractères minimum, longues et uniques) :
   ```sql
   insert into public.teams (code, name, publish_key)
   values ('CODE-EQUIPE-LONG-ET-UNIQUE', 'Eagle Message Tabernacle', 'CLE-DE-PUBLICATION-SECRETE');
   ```
4. Va dans **Project Settings** puis **API Keys**. Copie :
   - **Project URL** (commence par `https://`, visible dans « Data API » ou en haut du projet),
   - la clé **Publishable** (`sb_publishable_…`). Si tu ne la vois pas, ouvre l'onglet **Legacy API Keys** et prends la clé **anon**.
   **Ne copie jamais la clé « secret » ni « service_role » : elles donnent tous les droits.**
5. Ouvre `site/config.js` et remplis :
   ```js
   window.EAGLE_CONFIG = {
     supabaseUrl: "https://xxxx.supabase.co",
     supabaseKey: "ta-clé-publishable-ou-anon"
   };
   ```
6. Remets le site en ligne (glisse de nouveau le dossier `site` sur Netlify, ou modifie le fichier dans GitHub).

## 5. Utilisation par l'équipe

- **Le chanteur** : Chansons, puis Listes. Il prépare sa liste (date, chanteur), ouvre « Équipe (partage en ligne) »,
  entre le code de l'équipe et la clé de publication, puis touche « Publier pour l'équipe ».
- **Les musiciens** : Chansons, puis Listes. Ils entrent seulement le code de l'équipe et touchent
  « Recevoir les programmes », puis « Ajouter ». Ils reçoivent les chansons, les accords et les notes pour chaque instrument.
- Republier le même programme (même nom et même date) le remplace.
- Donne le **code** à tous les musiciens. Donne la **clé de publication** seulement à ceux qui publient.

## 6. Mettre à jour l'application

Remplace `site/index.html` par la nouvelle version (garde `config.js`). Les téléphones récupèrent
la nouvelle version à la prochaine ouverture avec internet.

## 7. Sécurité et limites

- Le code de l'équipe fonctionne comme un mot de passe de lecture : choisis-le long et ne le publie pas.
- Les tables Supabase sont fermées. Tout passe par 4 fonctions qui vérifient le code (et la clé pour publier ou supprimer).
- Les chansons et les listes sont enregistrées sur chaque téléphone. Utilise « Sauvegarder tout » de temps en temps.
- Les enregistrements audio et les boucles du batteur restent sur le téléphone où ils ont été faits.
- Les paroles et les accords sont protégés par des droits d'auteur : vérifie la licence de l'église (par exemple CCLI) avant de les partager.
