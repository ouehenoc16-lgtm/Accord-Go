// Partage d'équipe en ligne (facultatif).
// Laisse ces deux lignes vides pour utiliser l'application sans internet.
// Pour activer le partage : crée un projet Supabase puis colle ici son adresse et sa clé « publishable » (ou « anon »)
// (voir le fichier README.md, étape 4).
window.EAGLE_CONFIG = {
  supabaseUrl: "",
  supabaseKey: ""
};
